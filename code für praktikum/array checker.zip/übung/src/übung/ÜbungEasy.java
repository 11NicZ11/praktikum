package übung;

import java.util.Scanner;

public class ÜbungEasy {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size of you array");
		int size = sc.nextInt();
		int[] array = new int[size];
		char repeat = 0;
		int display;
		do {
display();		


 display = sc.nextInt();
 if (display !=6) {
	switch(display) {
	case 1:
		System.out.println("Input up to "+size+" digits");
		createArray(array);
	break;
	
	case 2: 
		max(array);
		min(array);
		break;
		
	case 3: 
		sumArray(array);
		break;
		
	case 4: 
		findKey(array);
		break;
	case 5: 
		showArray(array);
		break;
	}
		
		}else {
			System.out.println("goodbye");
			repeat='b';
		}
 System.out.println("wanna continue?");
 repeat = sc.next().charAt(0);
		}  while( repeat == 'y' || repeat == 'Y');
	}
	
	private static void createArray(int[] arrayIn) {
		for(int i=0; i<arrayIn.length;i++) {
			Scanner sc = new Scanner(System.in);
			arrayIn[i]= sc.nextInt();
		}
		
	}

	private static void showArray(int... arrayIn) {
		for(int show : arrayIn)
			System.out.println(show);
		
	}

	private static void min(int...arrayIn ) {
		int smallest = arrayIn[0], loc = arrayIn[0];
		
		for (int i= 0; i < arrayIn.length;i++) {
			if(arrayIn[i] < smallest) 
				smallest = arrayIn[i];
			loc = i;
			
		}
		
		System.out.println("smallest number: "+smallest+" on position: "+ loc);
	}
	
	private static void max(int... arrayIn ) {
		int max = arrayIn[0];
		for (int i = 0; i < arrayIn.length;i++) {
			if (arrayIn[i] > max)
				max = arrayIn[i];
		}
		
		
		System.out.println(max);
	}
	
	
	
private static void display() {
		System.out.println("pls input a number to select a feature for your array");
		System.out.println("1: Enter Values");
		System.out.println("2: Find maximum");
		System.out.println("3: Calculate sum");
		System.out.println("4: Check for integer");
		System.out.println("5: Display array");
		System.out.println("6: Exit");
	}
private static void sumArray(int... arrayIn) {
	int sum = 0;
	for (int i : arrayIn) {
		sum+=i;
	}
	System.out.println("summe: "+sum);
	
}
	
private static void findKey(int[] arrayIn ) {
	Scanner sc = new Scanner(System.in);
	boolean result = false;
	int key = sc.nextInt();
	
		for (int n : arrayIn) 
		if( n == key) {
	result=true;
		}
	
	System.out.println(result);
}


	}

