/**
 * 
 */
/**
 * @author User
 *
 */
module GURPSdice {
}