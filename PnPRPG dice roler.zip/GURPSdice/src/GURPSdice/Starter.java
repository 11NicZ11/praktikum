package GURPSdice;
import java.util.Random;
import java.util.Scanner;

public class Starter {

	static Random rand = new Random();
	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		int attacks;
		int hit=0;
		int hitL = 0;
		int saberHit = 14;

		
		
		
		
		
		
	Display();	
	int	n= sc.nextInt();
		switch(n) {
		case 1:

			do {
					
				System.out.println("How many attacks do u want to do?");
				
				attacks =sc.nextInt();
				for(int a =0;a<attacks;a++) {
					if(hit!=0) {
						
						hit = 0;
					}
					int hit1 = rand.nextInt(6);
					int hit2 = rand.nextInt(6);
					int hit3 = rand.nextInt(6);
					hit  = (hit1+1) + (hit2+1) + (hit3+1);
					
						
					if(hit <= saberHit) {
						System.out.println("angriff "+(a+1)+" roll: "+ hit+" Hit by "+(saberHit-hit));
						
							
							if (hitL !=0) {
								hitL=0;
							}
							int hitl1 = rand.nextInt(6);
							int hitl2 = rand.nextInt(6);
							int hitl3 = rand.nextInt(6);
							hitL = (hitl1+1)+(hitl2+1)+(hitl3+1);
							if(hitL <=4) {
								System.out.println("Hit Skull "+ hitL);
							}else if(hitL==5) {
								System.out.println("Hit Face "+ hitL);
							}else if(hitL ==6 || hitL ==7) {
								System.out.println("Hit Right Leg "+hitL);
							}else if(hitL == 8) {
								System.out.println("Hit Right Arm "+ hitL);
							}else if(hitL ==9 || hitL ==10) {
								System.out.println("Hit Torso "+ hitL);
							}else if(hitL==11) {
								System.out.println("Hit Groin "+ hitL);
							}else if(hitL==12) {
								System.out.println("Hit Left Arm "+ hitL);
							}else if(hitL==13 || hitL==14) {
								System.out.println("Hit LeftLeg "+ hitL);
							}else if(hitL==15) {
								System.out.println("Hit Hand "+ hitL);
							}else if(hitL==16) {
								System.out.println("Hit Foot "+ hitL);
							}else {
								System.out.println("Hit Neck "+ hitL);
							}
						
					}else {
						System.out.println("angriff "+(a+1)+" roll: "+ hit+" fail by "+(hit-saberHit));						
					}
					}
				
				}while(attacks>0 && attacks<=100);
			break;
		case 2:
			break;
		}
		
		
		
	}

	private static void Display() {
		System.out.println("Pls enter what you are rolling for");
		System.out.println("1: Attack");
		System.out.println("2: spell");
		System.out.println("3: skill");
		System.out.println("4: Dissadvantage");
		System.out.println("5: attributes");
		System.out.println("6: leave");
	}
}
